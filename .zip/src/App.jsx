import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import DashboardLayout from './pages/DashboardLayout';
import Home from './pages/dashboard/Home';
import Learn from './pages/dashboard/Learn';
import DailyQuestion from './pages/dashboard/DailyQuestion';
import TestKnowledge from './pages/dashboard/TestKnowledge';
import Schemes from './pages/dashboard/Schemes';
import Community from './pages/dashboard/Community';
import Scanner from './pages/dashboard/Scanner';
import AskAI from './pages/dashboard/AskAI';
import Profile from './pages/dashboard/Profile';
import WhatsApp from './pages/dashboard/WhatsApp';
import Progress from './pages/dashboard/Progress';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/dashboard" element={<DashboardLayout />}>
          <Route index element={<Home />} />
          <Route path="ask" element={<AskAI />} />
          <Route path="learn" element={<Learn />} />
          <Route path="daily-question" element={<DailyQuestion />} />
          <Route path="test" element={<TestKnowledge />} />
          <Route path="community" element={<Community />} />
          <Route path="schemes" element={<Schemes />} />
          <Route path="scanner" element={<Scanner />} />
          <Route path="profile" element={<Profile />} />
          <Route path="whatsapp" element={<WhatsApp />} />
          <Route path="progress" element={<Progress />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
