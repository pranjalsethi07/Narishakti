import React from 'react';
import { Smartphone, QrCode, PhoneForwarded } from 'lucide-react';

const WhatsApp = () => {
  return (
    <div className="fade-in" style={styles.container}>
      <header style={{marginBottom: '32px'}}>
        <h1 className="h2" style={{color: 'var(--text-dark)'}}>WhatsApp Integration</h1>
        <p className="subtext">Chat with NariShakti offline and locally on WhatsApp</p>
      </header>

      <div style={styles.flexContainer}>
        <div style={styles.card}>
          <h2 style={{fontSize: '1.2rem', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '8px'}}>
            <Smartphone color="#25D366" />
            Connect immediately
          </h2>

          <div style={styles.instructionBox}>
            <div style={styles.stepCircle}>1</div>
            <div>
              <h4>Method 1: Give a Missed Call</h4>
              <p className="subtext">Missed call on <strong>+91 98765 43210</strong>. We will WhatsApp you!</p>
              <button className="btn btn-secondary" style={{marginTop: '12px', padding: '8px 16px', backgroundColor: '#e6ffe6', color: '#25D366', fontWeight: 'bold'}}>
                <PhoneForwarded size={18} /> Missed Call
              </button>
            </div>
          </div>

          <div style={styles.instructionBox}>
            <div style={styles.stepCircle}>2</div>
            <div>
              <h4>Method 2: Scan QR Code</h4>
              <p className="subtext">Scan this QR code from your mobile</p>
              <div style={styles.qrPlaceholder}>
                <QrCode size={80} color="var(--text-muted)" />
                <p>QR Code</p>
              </div>
            </div>
          </div>

          <button className="btn btn-primary" style={{width: '100%', backgroundColor: '#25D366', color: '#fff'}}>
            Open WhatsApp
          </button>
        </div>

        <div style={styles.mockPhone}>
          <div style={styles.mockScreen}>
            <div style={styles.mockHeader}>
              <div style={{width: '30px', height: '30px', borderRadius: '50%', backgroundColor: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <span style={{color: '#075E54', fontWeight: 'bold', fontSize: '0.8rem'}}>NS</span>
              </div>
              <span style={{color: '#fff', fontWeight: '600'}}>NariShakti Didi</span>
            </div>
            <div style={styles.mockChatArea}>
              <div style={styles.mockMsgIn}>
                <p>Namaste! Aapne miss call diya tha. Mai NariShakti AI aapki madad ke liye taiyar hu. Aaj aapko kya janna hai?</p>
              </div>
              <div style={styles.mockMsgOut}>
                <p>Mudr yojana kya hai?</p>
              </div>
              <div style={styles.mockMsgIn}>
                <p>Mudra Yojana ek government scheme hai jo chote businesses start karne ke liye bina collateral ke loan deti hai. Kya main aapko Iski eligibility batau?</p>
              </div>
            </div>
            <div style={styles.mockInputArea}>
              <span style={{color: '#a0aec0'}}>Message...</span>
              <div style={{width: '32px', height: '32px', borderRadius: '50%', backgroundColor: '#075E54', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <Mic size={16} color="#fff" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '900px',
    margin: '0 auto',
  },
  flexContainer: {
    display: 'flex',
    gap: '40px',
    flexWrap: 'wrap',
  },
  card: {
    flex: 1,
    minWidth: '300px',
    backgroundColor: 'var(--surface)',
    padding: '32px',
    borderRadius: 'var(--radius-lg)',
    boxShadow: 'var(--shadow-md)',
    border: '1px solid var(--border-color)',
  },
  instructionBox: {
    display: 'flex',
    gap: '16px',
    marginBottom: '32px',
  },
  stepCircle: {
    width: '30px',
    height: '30px',
    borderRadius: '50%',
    backgroundColor: 'var(--primary-light)',
    color: 'var(--primary-dark)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: 'bold',
    flexShrink: 0,
  },
  qrPlaceholder: {
    marginTop: '16px',
    width: '150px',
    height: '150px',
    border: '2px dashed var(--border-color)',
    borderRadius: 'var(--radius-md)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
  },
  mockPhone: {
    width: '300px',
    height: '550px',
    backgroundColor: '#000',
    borderRadius: '32px',
    padding: '8px',
    boxShadow: 'var(--shadow-lg)'
  },
  mockScreen: {
    height: '100%',
    backgroundColor: '#efeae2',
    borderRadius: '24px',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column'
  },
  mockHeader: {
    backgroundColor: '#075E54',
    padding: '32px 16px 16px',
    display: 'flex',
    alignItems: 'center',
    gap: '12px'
  },
  mockChatArea: {
    flex: 1,
    padding: '16px',
    overflowY: 'auto',
    display: 'flex',
    flexDirection: 'column',
    gap: '12px'
  },
  mockMsgIn: {
    backgroundColor: '#fff',
    padding: '12px',
    borderRadius: '0 12px 12px 12px',
    fontSize: '0.9rem',
    maxWidth: '85%',
    alignSelf: 'flex-start',
    boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
  },
  mockMsgOut: {
    backgroundColor: '#dcf8c6',
    padding: '12px',
    borderRadius: '12px 0 12px 12px',
    fontSize: '0.9rem',
    maxWidth: '85%',
    alignSelf: 'flex-end',
    boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
  },
  mockInputArea: {
    backgroundColor: '#f0f0f0',
    padding: '12px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    margin: '8px',
    borderRadius: '24px',
  }
};

export default WhatsApp;
