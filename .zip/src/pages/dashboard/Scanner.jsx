import React, { useState } from 'react';
import { Upload, FileText, CheckCircle, Volume2, Search } from 'lucide-react';

const Scanner = () => {
  const [file, setFile] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);

  const handleUpload = (e) => {
    e.preventDefault();
    setFile("Bank_Statement_Jan.pdf");
    setAnalyzing(true);
    
    setTimeout(() => {
      setAnalyzing(false);
      setResult({
        type: "Bank Statement",
        summary: "Aapke bank khate mein pichle mahine choti-choti bahut si katauti hui hain jo ki ATM charges lag rahi hain. Aapne total ₹1,200 save kiye hain.",
        summaryEn: "There are multiple small deductions in your account last month which appear to be ATM charges. You saved a total of ₹1,200.",
        highlights: [
          "ATM withdrawal charge: ₹25 x 4 = ₹100",
          "Closing Balance: ₹14,500",
          "Interest credited: ₹45"
        ]
      });
    }, 2000);
  };

  return (
    <div className="fade-in" style={styles.container}>
      <header style={{marginBottom: '32px'}}>
        <h1 className="h2" style={{color: 'var(--text-dark)'}}>Document Simplifier</h1>
        <p className="subtext">Upload complex documents and get it explained in simple language</p>
      </header>

      {!result && (
        <div style={styles.uploadArea} onClick={handleUpload} className="hover-card">
          <div style={styles.iconCircle}>
            <Upload size={32} color="var(--primary)" />
          </div>
          <h3 style={{marginTop: '16px', marginBottom: '8px'}}>Click to upload or scan</h3>
          <p className="subtext" style={{textAlign: 'center', maxWidth: '300px'}}>
            Bank Statements, Medical Prescriptions, Government Forms (PDF, JPG)
          </p>
          
          {analyzing && (
            <div style={{marginTop: '24px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px'}}>
              <div className="loading-dots">
                <span></span><span></span><span></span>
              </div>
              <p style={{color: 'var(--primary)'}}>Reading document...</p>
            </div>
          )}
        </div>
      )}

      {result && (
        <div style={styles.resultCard} className="fade-in">
          <div style={styles.resultHeader}>
            <div style={{display: 'flex', alignItems: 'center', gap: '12px'}}>
              <FileText size={24} color="var(--primary)" />
              <h3 style={{fontSize: '1.2rem'}}>Analysis: {result.type}</h3>
            </div>
            <button className="btn btn-secondary" style={{padding: '8px 16px', borderRadius: '50px'}}>
              <Volume2 size={18} /> Listen
            </button>
          </div>

          <div style={styles.summaryBox}>
            <h4 style={{marginBottom: '8px', color: 'var(--primary-dark)'}}>Simple Explanation:</h4>
            <p style={{fontSize: '1.1rem', marginBottom: '8px'}}>{result.summary}</p>
            <p style={{fontSize: '0.95rem', color: 'var(--text-muted)'}}>{result.summaryEn}</p>
          </div>

          <div style={styles.highlightsBox}>
            <h4 style={{marginBottom: '12px'}}>Important Information:</h4>
            <ul style={{listStyle: 'none', padding: 0}}>
              {result.highlights.map((hlt, idx) => (
                <li key={idx} style={{display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px'}}>
                  <CheckCircle size={16} color="var(--success)" />
                  <span>{hlt}</span>
                </li>
              ))}
            </ul>
          </div>

          <button className="btn btn-primary" onClick={() => {setResult(null); setFile(null);}} style={{marginTop: '24px'}}>
            Scan Another Document
          </button>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '700px',
    margin: '0 auto',
  },
  uploadArea: {
    border: '2px dashed var(--primary)',
    backgroundColor: 'var(--surface)',
    borderRadius: 'var(--radius-lg)',
    padding: '60px 40px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    transition: 'all 0.2s',
  },
  iconCircle: {
    width: '80px',
    height: '80px',
    borderRadius: '50%',
    backgroundColor: 'var(--primary-light)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  resultCard: {
    backgroundColor: 'var(--surface)',
    borderRadius: 'var(--radius-lg)',
    padding: '32px',
    boxShadow: 'var(--shadow-md)',
    border: '1px solid var(--border-color)',
  },
  resultHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '24px',
    paddingBottom: '24px',
    borderBottom: '1px solid var(--border-color)',
  },
  summaryBox: {
    backgroundColor: '#f0e6ff',
    padding: '20px',
    borderRadius: 'var(--radius-md)',
    marginBottom: '24px',
    borderLeft: '4px solid var(--primary)',
  },
  highlightsBox: {
    padding: '20px',
    backgroundColor: 'var(--bg-color)',
    borderRadius: 'var(--radius-md)',
    border: '1px solid var(--border-color)',
  }
};

export default Scanner;
