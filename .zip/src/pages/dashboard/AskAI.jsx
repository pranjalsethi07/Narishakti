import React, { useState, useEffect, useRef } from 'react';
import { Mic, Send, Volume2, StopCircle } from 'lucide-react';

const AskAI = () => {
  const [messages, setMessages] = useState([
    { id: 1, sender: 'ai', text: 'Namaste! Meri madad aapko kaise chahiye? (How can I help you today?)', time: '10:00 AM' }
  ]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim() || isThinking) return;

    const userText = input.trim();
    const newMsg = { id: Date.now(), sender: 'user', text: userText, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) };
    setMessages(prev => [...prev, newMsg]);
    setInput('');
    setIsThinking(true);

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        signal: controller.signal,
        body: JSON.stringify({ message: userText }),
      });
      clearTimeout(timeout);

      const rawText = await response.text();
      let data = {};
      if (rawText) {
        try {
          data = JSON.parse(rawText);
        } catch {
          data = { error: rawText };
        }
      }

      if (!response.ok) {
        throw new Error(data?.error || 'Unable to get response from assistant.');
      }

      setMessages(prev => [...prev, {
        id: Date.now(),
        sender: 'ai',
        text: data.reply || 'Maaf kijiye, assistant ne empty response diya. Kripya dobara try karein.',
        time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
        hasAudio: true
      }]);
    } catch (error) {
      const message = error?.name === 'AbortError'
        ? 'Request timed out. Kripya dobara try karein.'
        : error.message;
      setMessages(prev => [...prev, {
        id: Date.now(),
        sender: 'ai',
        text: `Maaf kijiye, abhi server se connect nahi ho pa raha. (${message})`,
        time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
      }]);
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="fade-in" style={styles.container}>
      <header style={styles.header}>
        <div style={{display: 'flex', alignItems: 'center', gap: '16px'}}>
          <div style={styles.avatar}>
            <span style={{color: 'white', fontWeight: 'bold'}}>AI</span>
          </div>
          <div>
            <h1 className="h2" style={{fontSize: '1.2rem', color: 'var(--text-dark)'}}>NariShakti Assistant</h1>
            <p className="subtext" style={{color: 'var(--success)'}}>● Online (Private & Secure)</p>
          </div>
        </div>
      </header>

      <div style={styles.chatArea}>
        <div style={styles.dateLabel}>Today</div>
        
        {messages.map(msg => (
          <div key={msg.id} style={{
            ...styles.messageWrapper,
            justifyContent: msg.sender === 'user' ? 'flex-end' : 'flex-start'
          }}>
            <div style={{
              ...styles.messageBubble,
              backgroundColor: msg.sender === 'user' ? '#d9fdd3' : 'var(--surface)',
              borderBottomRightRadius: msg.sender === 'user' ? '4px' : 'var(--radius-lg)',
              borderBottomLeftRadius: msg.sender === 'ai' ? '4px' : 'var(--radius-lg)',
            }}>
              <p style={{marginBottom: '4px', fontSize: '1rem'}}>{msg.text}</p>
              
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px'}}>
                <span style={{fontSize: '0.75rem', color: 'var(--text-muted)'}}>{msg.time}</span>
                {msg.sender === 'ai' && (
                  <button style={styles.inlinePlayBtn}>
                    <Volume2 size={16} /> Play
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        <div style={styles.suggestionsContainer}>
          <button style={styles.suggestionBtn} onClick={() => setInput("Ask about periods")}>"Ask about periods"</button>
          <button style={styles.suggestionBtn} onClick={() => setInput("Check bank balance")}>"Check bank balance"</button>
        </div>

        <div ref={messagesEndRef} />
      </div>

      <form style={styles.inputArea} onSubmit={handleSend}>
        <button 
          type="button"
          onClick={() => setIsRecording(!isRecording)} 
          style={{...styles.micBtn, backgroundColor: isRecording ? 'var(--danger)' : 'var(--primary)'}}
          className={isRecording ? 'mic-pulse' : ''}
        >
          {isRecording ? <StopCircle size={24} color="#fff" /> : <Mic size={24} color="#fff" />}
        </button>
        
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={isRecording ? "Listening..." : "Message type karein..."}
          style={styles.input}
          disabled={isRecording}
        />
        
        <button type="submit" style={styles.sendBtn} disabled={!input.trim() || isThinking}>
          <Send size={24} color={input.trim() ? "var(--primary)" : "var(--text-light)"} />
        </button>
      </form>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '800px',
    margin: '0 auto',
    height: 'calc(100vh - 120px)',
    display: 'flex',
    flexDirection: 'column',
    backgroundColor: '#efeae2', // WhatsApp-like bg
    borderRadius: 'var(--radius-lg)',
    overflow: 'hidden',
    boxShadow: 'var(--shadow-md)',
  },
  header: {
    backgroundColor: 'var(--surface)',
    padding: '16px 24px',
    display: 'flex',
    alignItems: 'center',
    borderBottom: '1px solid var(--border-color)',
    zIndex: 10
  },
  avatar: {
    width: '45px',
    height: '45px',
    borderRadius: '50%',
    backgroundColor: 'var(--primary)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  chatArea: {
    flex: 1,
    padding: '24px',
    overflowY: 'auto',
    display: 'flex',
    flexDirection: 'column',
    gap: '12px'
  },
  dateLabel: {
    alignSelf: 'center',
    backgroundColor: 'rgba(255,255,255,0.6)',
    padding: '4px 12px',
    borderRadius: 'var(--radius-md)',
    fontSize: '0.8rem',
    color: 'var(--text-muted)',
    marginBottom: '16px'
  },
  messageWrapper: {
    display: 'flex',
    width: '100%'
  },
  messageBubble: {
    maxWidth: '70%',
    padding: '12px 16px',
    borderRadius: 'var(--radius-lg)',
    boxShadow: 'var(--shadow-sm)',
    position: 'relative'
  },
  inlinePlayBtn: {
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
    color: 'var(--primary)',
    fontSize: '0.8rem',
    fontWeight: '600'
  },
  suggestionsContainer: {
    display: 'flex',
    gap: '12px',
    marginTop: 'auto',
    paddingTop: '20px',
    overflowX: 'auto',
    paddingBottom: '8px'
  },
  suggestionBtn: {
    whiteSpace: 'nowrap',
    padding: '8px 16px',
    backgroundColor: 'var(--surface)',
    border: '1px solid var(--primary)',
    color: 'var(--primary-dark)',
    borderRadius: 'var(--radius-full)',
    fontSize: '0.9rem',
    boxShadow: 'var(--shadow-sm)'
  },
  inputArea: {
    backgroundColor: 'var(--surface)',
    padding: '16px 24px',
    display: 'flex',
    alignItems: 'center',
    gap: '16px'
  },
  micBtn: {
    width: '50px',
    height: '50px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    transition: 'background-color 0.2s'
  },
  input: {
    flex: 1,
    padding: '16px 20px',
    borderRadius: 'var(--radius-full)',
    border: '1px solid var(--border-color)',
    backgroundColor: 'var(--bg-color)',
    fontSize: '1rem',
    outline: 'none',
  },
  sendBtn: {
    width: '40px',
    height: '40px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent'
  }
};

export default AskAI;
