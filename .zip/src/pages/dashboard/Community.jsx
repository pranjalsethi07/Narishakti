import React, { useState } from 'react';
import { ShieldCheck, MessageCircle, Heart, Volume2, UserCircle2, Send, Mic } from 'lucide-react';

const Community = () => {
  const [activeTab, setActiveTab] = useState('all');

  const posts = [
    {
      id: 1,
      category: 'Health',
      author: 'Anonymous',
      time: '2 hours ago',
      content: 'Meri period cycle irregular hai pichle 3 mahine se. Kya mujhe doctor ko dikhana chahiye? Ghar pe sab bolte hai normal hai par mujhe tension ho rahi hai.',
      contentEn: 'My period cycle has been irregular for 3 months. Should I see a doctor?',
      likes: 24,
      replies: 5,
      hasExpertReply: true
    },
    {
      id: 2,
      category: 'Safety',
      author: 'Anonymous',
      time: '5 hours ago',
      content: 'Local bus me travel karte waqt agar koi pareshan kare toh emergency helpline 112 pe turant call karni chahiye. Maine kal use kiya tha, police 10 min me aa gayi.',
      contentEn: 'If someone bothers you on local buses, immediately call 112.',
      likes: 156,
      replies: 12,
      hasExpertReply: false
    },
    {
      id: 3,
      category: 'Finance',
      author: 'Anonymous',
      time: '1 day ago',
      content: 'Silai ke business ke liye bina collateral ke loan kahan se mil sakta hai? Mudra yojna try kiya tha par paperwork samajh nahi aa raha.',
      contentEn: 'Where can I get a collateral-free loan for my tailoring business?',
      likes: 42,
      replies: 8,
      hasExpertReply: true
    }
  ];

  return (
    <div className="fade-in" style={styles.container}>
      <header style={styles.header}>
        <div>
          <h1 className="h2" style={{color: 'var(--text-dark)'}}>Didi Connect</h1>
          <p className="subtext">A safe, anonymous space by women, for women</p>
        </div>
        <div style={styles.badge}>
          <ShieldCheck color="var(--success)" size={20} />
          <span style={styles.badgeText}>Safe & Verified Space</span>
        </div>
      </header>

      <div style={styles.createPostCard} className="hover-card">
        <div style={{display: 'flex', gap: '16px'}}>
          <UserCircle2 size={40} color="var(--text-light)" />
          <div style={{flex: 1}}>
            <textarea 
              placeholder="Ask anything anonymously without fear... (Health, Finance, Safety)"
              style={styles.textarea}
              rows={3}
            ></textarea>
            <div style={styles.postActions}>
              <div style={{display: 'flex', gap: '16px'}}>
                <button style={{...styles.actionBtn, color: 'var(--primary)'}}>
                  <Mic size={18} /> Voice Post
                </button>
                <div style={styles.anonToggle}>
                  <input type="checkbox" id="anon" defaultChecked />
                  <label htmlFor="anon" style={{fontSize: '0.9rem'}}>Post Anonymously</label>
                </div>
              </div>
              <button className="btn btn-primary" style={{padding: '8px 20px'}}>
                <Send size={16} /> Post
              </button>
            </div>
          </div>
        </div>
      </div>

      <div style={styles.tabs}>
        {['All', 'Health', 'Finance', 'Safety'].map(tab => (
          <button 
            key={tab}
            style={{
              ...styles.tab, 
              backgroundColor: activeTab === tab.toLowerCase() ? 'var(--primary)' : 'var(--bg-color)',
              color: activeTab === tab.toLowerCase() ? '#fff' : 'var(--text-muted)'
            }}
            onClick={() => setActiveTab(tab.toLowerCase())}
          >
            {tab}
          </button>
        ))}
      </div>

      <div style={styles.feed}>
        {posts.map(post => (
          <div key={post.id} style={styles.postCard}>
            <div style={styles.postHeader}>
              <div style={{display: 'flex', alignItems: 'center', gap: '12px'}}>
                <div style={styles.avatar}>
                  <UserCircle2 size={32} color="var(--primary)" />
                </div>
                <div>
                  <h4 style={{fontSize: '1rem', fontWeight: '600'}}>{post.author}</h4>
                  <span className="subtext" style={{fontSize: '0.8rem'}}>{post.time} • {post.category}</span>
                </div>
              </div>
              <button className="btn btn-secondary" style={styles.listenBtn}>
                <Volume2 size={16} />
              </button>
            </div>
            
            <p style={styles.postContent}>{post.content}</p>
            <p style={styles.postContentEn}>{post.contentEn}</p>

            {post.hasExpertReply && (
              <div style={styles.expertBadge}>
                <ShieldCheck size={14} color="#000" />
                <span>Verified Expert Reply inside</span>
              </div>
            )}

            <div style={styles.postFooter}>
              <button style={styles.footerBtn}>
                <Heart size={18} color="var(--text-muted)" />
                <span>{post.likes} Helpful</span>
              </button>
              <button style={styles.footerBtn}>
                <MessageCircle size={18} color="var(--text-muted)" />
                <span>{post.replies} Replies</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '700px',
    margin: '0 auto',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '24px'
  },
  badge: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '8px 16px',
    backgroundColor: '#f0fff4',
    border: '1px solid #c6f6d5',
    borderRadius: 'var(--radius-full)',
  },
  badgeText: {
    color: 'var(--success)',
    fontWeight: '600',
    fontSize: '0.9rem'
  },
  createPostCard: {
    backgroundColor: 'var(--surface)',
    padding: '24px',
    borderRadius: 'var(--radius-md)',
    boxShadow: 'var(--shadow-md)',
    border: '1px solid var(--border-color)',
    marginBottom: '32px'
  },
  textarea: {
    width: '100%',
    border: '1px solid var(--border-color)',
    borderRadius: 'var(--radius-md)',
    padding: '12px',
    fontFamily: 'inherit',
    fontSize: '1rem',
    resize: 'none',
    outline: 'none',
    marginBottom: '12px',
    backgroundColor: 'var(--bg-color)'
  },
  postActions: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  actionBtn: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    fontSize: '0.9rem',
    fontWeight: '500'
  },
  anonToggle: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px'
  },
  tabs: {
    display: 'flex',
    gap: '12px',
    marginBottom: '24px'
  },
  tab: {
    padding: '8px 20px',
    borderRadius: 'var(--radius-full)',
    border: '1px solid var(--border-color)',
    fontWeight: '500',
    transition: 'all 0.2s',
  },
  feed: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  },
  postCard: {
    backgroundColor: 'var(--surface)',
    padding: '24px',
    borderRadius: 'var(--radius-md)',
    border: '1px solid var(--border-color)',
    boxShadow: 'var(--shadow-sm)'
  },
  postHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '16px'
  },
  avatar: {
    width: '40px',
    height: '40px',
    borderRadius: '50%',
    backgroundColor: 'var(--primary-light)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  listenBtn: {
    padding: '8px',
    borderRadius: '50%'
  },
  postContent: {
    fontSize: '1.05rem',
    lineHeight: 1.5,
    marginBottom: '8px',
    color: 'var(--text-dark)'
  },
  postContentEn: {
    fontSize: '0.95rem',
    color: 'var(--text-muted)',
    fontStyle: 'italic',
    marginBottom: '16px'
  },
  expertBadge: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    padding: '6px 12px',
    backgroundColor: '#ffd84c',
    borderRadius: 'var(--radius-full)',
    fontSize: '0.8rem',
    fontWeight: '600',
    marginBottom: '16px'
  },
  postFooter: {
    display: 'flex',
    gap: '24px',
    borderTop: '1px solid var(--border-color)',
    paddingTop: '16px'
  },
  footerBtn: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    color: 'var(--text-muted)',
    fontWeight: '500',
    fontSize: '0.95rem',
    transition: 'color 0.2s'
  }
};

export default Community;
