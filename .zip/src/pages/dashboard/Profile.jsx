import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { User, Award, Settings, Bell, Shield, LogOut, CheckCircle2 } from 'lucide-react';

const Profile = () => {
  const { t, lang } = useLanguage();
  const [userName] = useState(localStorage.getItem('userName') || 'Didi');
  const [userAge] = useState(localStorage.getItem('userAge') || 'Unknown');
  const [privacyMode, setPrivacyMode] = useState(true);
  const [profileComplete, setProfileComplete] = useState(localStorage.getItem('profileComplete') === 'true');

  const handleLogout = () => {
    localStorage.clear();
    window.location.href = '/';
  };

  const completeProfile = () => {
    localStorage.setItem('profileComplete', 'true');
    setProfileComplete(true);
  };

  return (
    <div className="fade-in" style={styles.container}>
      <header style={{marginBottom: '32px'}}>
        <h1 className="h2" style={{color: 'var(--text-dark)'}}>{t('myProfile')}</h1>
        <p className="subtext">{t('trackProgress')}</p>
      </header>

      <div style={styles.profileCard}>
        <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: '24px'}}>
            <div style={styles.avatarLarge}>
              <span style={{fontSize: '2rem', color: '#fff'}}>{userName.charAt(0)}</span>
            </div>
            <div>
              <h2 style={{fontSize: '1.5rem', marginBottom: '4px'}}>{userName}</h2>
              <p className="subtext">{lang === 'hi' ? 'आयु वर्ग:' : 'Age Group:'} {userAge}</p>
              <div style={styles.levelBadge}>
                <Award size={16} color="#dd6b20" />
                <span style={{fontWeight: '600', color: '#dd6b20'}}>{lang === 'hi' ? 'स्तर: शिक्षार्थी' : 'Level: Learning'}</span>
              </div>
            </div>
          </div>
          
          {!profileComplete ? (
            <button className="btn btn-primary" onClick={completeProfile}>
              {t('completeProfile')}
            </button>
          ) : (
            <div style={{display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--success)', fontWeight: '600', backgroundColor: '#f0fff4', padding: '8px 16px', borderRadius: '50px', border: '1px solid #c6f6d5'}}>
              <CheckCircle2 size={18} />
              {lang === 'hi' ? 'प्रोफ़ाइल पूर्ण' : 'Profile Complete✓'}
            </div>
          )}
        </div>
      </div>

      <div style={styles.grid}>
        <div style={styles.sectionCard}>
          <h3 style={styles.sectionTitle}>{lang === 'hi' ? 'आपकी प्रगति' : 'Your Progress'}</h3>
          
          <div style={styles.statsGrid}>
            <div style={styles.statBox}>
              <h4 style={{fontSize: '2rem', color: 'var(--primary)', marginBottom: '4px'}}>42</h4>
              <p className="subtext">{t('questionsAsked')}</p>
            </div>
            <div style={styles.statBox}>
              <h4 style={{fontSize: '2rem', color: 'var(--accent)', marginBottom: '4px'}}>3</h4>
              <p className="subtext">{t('topicsCompleted')}</p>
            </div>
            <div style={styles.statBox}>
              <h4 style={{fontSize: '2rem', color: 'var(--secondary)', marginBottom: '4px'}}>5</h4>
              <p className="subtext">{t('dayStreak')}</p>
            </div>
          </div>
        </div>

        <div style={styles.sectionCard}>
          <h3 style={styles.sectionTitle}>{t('settings')}</h3>
          
          <div style={styles.settingsList}>
            <div style={styles.settingItem}>
              <div style={styles.settingText}>
                <Shield size={20} color="var(--primary)" />
                <div>
                  <h4 style={{fontWeight: '500'}}>{t('privacyMode')}</h4>
                  <p className="subtext" style={{fontSize: '0.8rem'}}>{lang === 'hi' ? '24 घंटे के बाद स्वचालित रूप से चैट हटाएं' : 'Automatically delete chats after 24 hrs'}</p>
                </div>
              </div>
              <label style={styles.toggle}>
                <input type="checkbox" checked={privacyMode} onChange={(e) => setPrivacyMode(e.target.checked)} style={{display:'none'}}/>
                <div style={{...styles.toggleThumb, backgroundColor: privacyMode ? 'var(--success)' : 'var(--text-light)', justifyContent: privacyMode ? 'flex-end' : 'flex-start'}}>
                  <div style={styles.toggleCircle}></div>
                </div>
              </label>
            </div>
            
            <div style={styles.settingItem}>
              <div style={styles.settingText}>
                <Bell size={20} color="var(--primary)" />
                <h4 style={{fontWeight: '500'}}>{lang === 'hi' ? 'दैनिक शिक्षण अनुस्मारक' : 'Daily Learning Reminders'}</h4>
              </div>
              <label style={styles.toggle}>
                <input type="checkbox" defaultChecked style={{display:'none'}}/>
                <div style={{...styles.toggleThumb, backgroundColor: 'var(--success)', justifyContent: 'flex-end'}}>
                  <div style={styles.toggleCircle}></div>
                </div>
              </label>
            </div>
          </div>
        </div>
      </div>
      
      <button className="btn btn-outline" style={{marginTop: '32px', color: 'var(--danger)', borderColor: 'var(--danger)'}} onClick={handleLogout}>
        <LogOut size={18} /> {t('logout')}
      </button>
    </div>
  );
};

const styles = {
  container: { maxWidth: '800px', margin: '0 auto' },
  profileCard: { backgroundColor: 'var(--surface)', padding: '32px', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-md)', marginBottom: '32px', border: '1px solid var(--border-color)' },
  avatarLarge: { width: '80px', height: '80px', borderRadius: '50%', backgroundColor: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' },
  levelBadge: { display: 'inline-flex', alignItems: 'center', gap: '8px', padding: '6px 16px', backgroundColor: '#feebc8', borderRadius: 'var(--radius-full)', marginTop: '12px', fontSize: '0.9rem' },
  grid: { display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: '24px' },
  sectionCard: { backgroundColor: 'var(--surface)', padding: '24px', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)', border: '1px solid var(--border-color)' },
  sectionTitle: { fontSize: '1.2rem', marginBottom: '20px', color: 'var(--text-dark)' },
  statsGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' },
  statBox: { backgroundColor: 'var(--bg-color)', padding: '16px', borderRadius: 'var(--radius-md)', textAlign: 'center', border: '1px solid var(--border-color)' },
  settingsList: { display: 'flex', flexDirection: 'column', gap: '20px' },
  settingItem: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: '16px', borderBottom: '1px solid var(--border-color)' },
  settingText: { display: 'flex', alignItems: 'center', gap: '12px' },
  toggle: { cursor: 'pointer' },
  toggleThumb: { width: '40px', height: '24px', borderRadius: '12px', display: 'flex', alignItems: 'center', padding: '2px', transition: 'background-color 0.2s' },
  toggleCircle: { width: '20px', height: '20px', backgroundColor: '#fff', borderRadius: '50%', boxShadow: 'var(--shadow-sm)' }
};

export default Profile;
