import React, { createContext, useState, useContext, useEffect } from 'react';

const LanguageContext = createContext();

export const translations = {
  en: {
    dashboard: "Dashboard",
    askAI: "Ask AI",
    learn: "Learn Step-by-Step",
    aajKaSawaal: "Aaj Ka Sawaal",
    testKnowledge: "Test Your Knowledge",
    community: "Didi Connect",
    schemes: "Govt Schemes",
    docScanner: "Doc Scanner",
    profile: "Profile",
    namaste: "Namaste",
    welcome: "Welcome back to your safe space!",
    quickActions: "Quick Actions",
    continueLearning: "Continue Learning",
    resume: "Resume",
    askAnything: "Ask Anything",
    searchPlaceholder: "Ask AI anything (Health, Finance, Schemes...)",
    playVoice: "Play Voice Response",
    appTitle: "NariShakti",
    logout: "Logout / Clear Data",
    schemesSubtitle: "Discover beneficial schemes, check eligibility, and apply.",
    checkEligibility: "Check Eligibility",
    allSchemes: "All Schemes",
    healthMotherhood: "Health & Motherhood",
    financeIndep: "Financial Independence",
    education: "Education",
    viewGovt: "View on Govt Portal",
    profileIncomplete: "Please complete your profile first to check eligibility.",
    completeProfile: "Complete Profile",
    myProfile: "My Profile",
    trackProgress: "Track your progress and manage settings",
    questionsAsked: "Questions Asked",
    topicsCompleted: "Topics Completed",
    dayStreak: "Day Streak",
    settings: "Settings",
    privacyMode: "Privacy Mode (Auto-delete chats)",
    languagePref: "Language Preference",
    
    // Landing Page
    landingSubtitle: "Health aur finance ke liye aapki AI saathi",
    getStarted: "Let's get started",
    yourName: "Aapka Naam (Your Name)",
    yourAge: "Aapki Umar (Your Age)",
    continueBtn: "Continue",
    privacyProtected: "🔒 Privacy-first: Your info is safe with us.",
    aboutUsNav: "About Us",
    shopNav: "Shop",
    testimonialsNav: "Stories",
    whoWeAre: "Who We Are & What We Do",
    aboutDesc1: "NariShakti is an AI-powered trusted companion designed exclusively for the women of India. We bridge the gap in female healthcare and financial literacy by providing a safe, judgment-free platform.",
    aboutDesc2: "Whether you have questions about menstrual hygiene, pregnancy, saving money, or government schemes, our Voice-first AI is here to answer them in simple, easy-to-understand language. We empower you to take control of your health and wealth.",
    factsTitle: "Did You Know?",
    fact1: "Only 18% of women in India have sole control over their bank accounts. We are here to change that.",
    fact2: "Over 70% of reproductive health issues can be prevented with early awareness and proper hygiene.",
    shopTitle: "Curated for You",
    shopSub: "High-quality female wellness products available on Amazon",
    testimonialsTitle: "What Our Didis Say",
    test1: "NariShakti helped me understand how to open my first bank account without depending on anyone.",
    test1Author: "- Sunita, 28",
    test2: "The Ask AI feature is like a doctor in my pocket. I don't feel shy asking questions about my body anymore.",
    test2Author: "- Priya, 22",
    askQue: "Ask a Que 🎤",
    chatWa: "Chat on WhatsApp",
    callUs: "Call par baat kare",
    buyProd: "Buy Products"
  },
  hi: {
    dashboard: "डैशबोर्ड (Dashboard)",
    askAI: "AI से पूछें",
    learn: "स्टेप-बाय-स्टेप सीखें",
    aajKaSawaal: "आज का सवाल",
    testKnowledge: "अपना ज्ञान परखें",
    community: "दीदी कनेक्ट (कम्युनिटी)",
    schemes: "सरकारी योजनाएं",
    docScanner: "डॉक्यूमेंट स्कैनर",
    profile: "प्रोफाइल",
    namaste: "नमस्ते",
    welcome: "आपके सुरक्षित स्थान पर वापस स्वागत है!",
    quickActions: "त्वरित कार्रवाई (Quick Actions)",
    continueLearning: "सीखना जारी रखें",
    resume: "फिर से शुरू करें",
    askAnything: "कुछ भी पूछें",
    searchPlaceholder: "AI से कुछ भी पूछें (स्वास्थ्य, वित्त, योजनाएं...)",
    playVoice: "आवाज़ में सुनें",
    appTitle: "नारीशक्ति",
    logout: "लॉगआउट / डेटा मिटाएं",
    schemesSubtitle: "लाभकारी योजनाएं खोजें और पात्रता जांचें।",
    checkEligibility: "पात्रता जांचें",
    allSchemes: "सभी योजनाएं",
    healthMotherhood: "स्वास्थ्य और मातृत्व",
    financeIndep: "आर्थिक स्वतंत्रता",
    education: "शिक्षा",
    viewGovt: "सरकारी पोर्टल पर देखें",
    profileIncomplete: "पात्रता जांचने के लिए कृपया पहले अपनी प्रोफाइल पूरी करें।",
    completeProfile: "प्रोफाइल पूरी करें",
    myProfile: "मेरी प्रोफाइल",
    trackProgress: "अपनी प्रगति ट्रैक करें और सेटिंग्स प्रबंधित करें",
    questionsAsked: "पूछे गए प्रश्न",
    topicsCompleted: "पूरे किए गए विषय",
    dayStreak: "दिन की स्ट्रीक",
    settings: "सेटिंग्स",
    privacyMode: "प्राइवेसी मोड (ऑटो-डिलीट चैट)",
    languagePref: "भाषा की पसंद (Language)",
    
    // Landing Page
    landingSubtitle: "स्वास्थ्य और वित्त के लिए आपकी AI साथी",
    getStarted: "चलिए शुरू करते हैं",
    yourName: "आपका नाम",
    yourAge: "आपकी उम्र",
    continueBtn: "आगे बढ़ें",
    privacyProtected: "🔒 प्राइवेसी-फर्स्ट: आपकी जानकारी हमारे पास सुरक्षित है।",
    aboutUsNav: "हमारे बारे में",
    shopNav: "दुकान (Shop)",
    testimonialsNav: "कहानियां",
    whoWeAre: "हम कौन हैं और क्या करते हैं",
    aboutDesc1: "नारीशक्ति एक एआई-संचालित विश्वसनीय साथी है जिसे विशेष रूप से भारत की महिलाओं के लिए बनाया गया है। हम एक सुरक्षित मंच प्रदान करके महिला स्वास्थ्य देखभाल और वित्तीय साक्षरता में अंतर को पाटते हैं।",
    aboutDesc2: "चाहे आपके पास मासिक धर्म की स्वच्छता, गर्भावस्था, पैसे बचाने, या सरकारी योजनाओं के बारे में प्रश्न हों, हमारी वॉयस-फर्स्ट एआई उन्हें सरल, समझने में आसान भाषा में उत्तर देने के लिए यहां है।",
    factsTitle: "क्या आप जानते हैं?",
    fact1: "भारत में केवल 18% महिलाओं का अपने बैंक खातों पर एकमात्र नियंत्रण है। हम इसे बदलने के लिए यहाँ हैं।",
    fact2: "70% से अधिक प्रजनन स्वास्थ्य समस्याओं को प्रारंभिक जागरूकता और उचित स्वच्छता से रोका जा सकता है।",
    shopTitle: "आपके लिए अनुशंसित",
    shopSub: "अमेज़ॅन पर उपलब्ध उच्च गुणवत्ता वाले महिला कल्याण उत्पाद",
    testimonialsTitle: "हमारी बहनें क्या कहती हैं",
    test1: "नारीशक्ति ने मुझे किसी पर निर्भर हुए बिना अपना पहला बैंक खाता खोलने का तरीका समझने में मदद की।",
    test1Author: "- सुनीता, 28",
    test2: "एआई से पूछें सुविधा मेरी जेब में एक डॉक्टर की तरह है। मुझे अब अपने शरीर के बारे में सवाल पूछने में शर्म नहीं आती।",
    test2Author: "- प्रिया, 22",
    askQue: "एक प्रश्न पूछें 🎤",
    chatWa: "WhatsApp पर चैट करें",
    callUs: "कॉल पर बात करें",
    buyProd: "उत्पाद खरीदें"
  }
};

export const LanguageProvider = ({ children }) => {
  const [lang, setLang] = useState(localStorage.getItem('appLang') || 'en');

  useEffect(() => {
    localStorage.setItem('appLang', lang);
  }, [lang]);

  const toggleLanguage = () => {
    setLang(prev => prev === 'en' ? 'hi' : 'en');
  };

  const t = (key) => {
    return translations[lang][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
