import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

/* global process */

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

app.get('/api/health', (_req, res) => {
  res.json({ ok: true });
});

app.post('/api/chat', async (req, res) => {
  try {
    const { message } = req.body || {};

    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ error: 'Message is required.' });
    }

    const apiKey = (
      process.env.OPENROUTER_API_KEY ||
      process.env.OPEN_ROUTER_API_KEY ||
      process.env.OPENROUTER_KEY ||
      process.env.GROQ_API_KEY
    )?.trim();
    if (!apiKey) {
      return res.status(500).json({ error: 'Missing OpenRouter API key in environment.' });
    }

    const model = process.env.OPENROUTER_MODEL?.trim() || 'openrouter/auto';
    const controller = new AbortController();
    const timeoutMs = 25000;
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    let response;
    try {
      response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
          'HTTP-Referer': 'http://localhost:5173',
          'X-Title': 'NariShakti Assistant',
        },
        signal: controller.signal,
        body: JSON.stringify({
          model,
          temperature: 0.5,
          max_tokens: 250,
          messages: [
            {
              role: 'system',
              content:
                'You are NariShakti Assistant. Reply in simple, respectful Hinglish or Hindi/English based on user language. Keep answers practical and concise for women-focused support topics.',
            },
            { role: 'user', content: message.trim() },
          ],
        }),
      });
    } finally {
      clearTimeout(timeout);
    }

    const raw = await response.text();
    let data = {};
    if (raw) {
      try {
        data = JSON.parse(raw);
      } catch {
        data = { error: { message: raw } };
      }
    }

    if (!response.ok) {
      const providerError = data?.error?.message || data?.error || 'OpenRouter request failed.';
      return res.status(502).json({ error: `OpenRouter error: ${providerError}` });
    }

    const reply =
      data?.choices?.[0]?.message?.content?.trim() ||
      'Maaf kijiye, abhi jawab generate nahi ho paaya. Kripya dobara try karein.';

    return res.json({ reply });
  } catch (error) {
    if (error?.name === 'AbortError') {
      return res.status(504).json({ error: 'AI request timed out. Please try again.' });
    }
    const detail = error?.message || String(error);
    console.error('OpenRouter chat error:', detail);
    return res.status(500).json({ error: `Failed to get AI response: ${detail}` });
  }
});

app.listen(port, () => {
  console.log(`AI backend running at http://localhost:${port}`);
});